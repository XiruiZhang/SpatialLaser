create function topoelementarray_append(topology.topoelementarray, topology.topoelement) returns topology.topoelementarray
    immutable
    language sql
as
$$
	SELECT CASE
		WHEN $1 IS NULL THEN
			topology.TopoElementArray('{' || $2::text || '}')
		ELSE
			topology.TopoElementArray($1::int[][]||$2::int[])
		END;
$$;

alter function topoelementarray_append(topology.topoelementarray, topology.topoelement) owner to postgres;

