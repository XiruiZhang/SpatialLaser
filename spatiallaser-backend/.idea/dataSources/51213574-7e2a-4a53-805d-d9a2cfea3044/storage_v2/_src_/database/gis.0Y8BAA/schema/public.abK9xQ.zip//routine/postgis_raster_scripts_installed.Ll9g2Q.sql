create function postgis_raster_scripts_installed() returns text
    immutable
    parallel safe
    language sql
as
$$ SELECT '2.4.4'::text || ' r' || 16526::text AS version $$;

alter function postgis_raster_scripts_installed() owner to postgres;

