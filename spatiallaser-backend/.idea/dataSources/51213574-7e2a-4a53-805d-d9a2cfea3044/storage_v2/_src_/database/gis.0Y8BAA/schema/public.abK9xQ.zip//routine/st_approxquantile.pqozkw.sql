create function st_approxquantile(rastertable text, rastercolumn text, nband integer, sample_percent double precision, quantiles double precision[] DEFAULT NULL::double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
    stable
    language sql
as
$$ SELECT public._ST_quantile($1, $2, $3, TRUE, $4, $5) $$;

alter function st_approxquantile(text, text, integer, double precision, double precision[], out double precision, out double precision) owner to postgres;

