create function topogeo_addgeometry(atopology character varying, ageom geometry, tolerance double precision DEFAULT 0) returns void
    language plpgsql
as
$$
DECLARE
BEGIN
	RAISE EXCEPTION 'TopoGeo_AddGeometry not implemented yet';
END
$$;

alter function topogeo_addgeometry(varchar, geometry, double precision) owner to postgres;

