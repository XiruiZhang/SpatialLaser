create function gettopogeomelements(tg topology.topogeometry) returns SETOF topology.topoelement
    stable
    strict
    language plpgsql
as
$$
DECLARE
  toponame varchar;
  rec RECORD;
BEGIN
  toponame = topology.GetTopologyName(tg.topology_id);
  FOR rec IN SELECT * FROM topology.GetTopoGeomElements(toponame,
    tg.layer_id,tg.id) as ret
  LOOP
    RETURN NEXT rec.ret;
  END LOOP;
  RETURN;
END;
$$;

comment on function gettopogeomelements(topology.topogeometry) is 'args: tg - Returns a set of topoelement objects containing the topological element_id,element_type of the given TopoGeometry (primitive elements)';

alter function gettopogeomelements(topology.topogeometry) owner to postgres;

