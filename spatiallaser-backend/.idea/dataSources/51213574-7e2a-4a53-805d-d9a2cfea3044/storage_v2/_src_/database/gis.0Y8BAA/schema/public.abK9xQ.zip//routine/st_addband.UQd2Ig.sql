create function st_addband(rast raster, index integer, pixeltype text, initialvalue double precision DEFAULT '0'::numeric, nodataval double precision DEFAULT NULL::double precision) returns raster
    immutable
    parallel safe
    language sql
as
$$ SELECT  public.ST_addband($1, ARRAY[ROW($2, $3, $4, $5)]::addbandarg[]) $$;

comment on function st_addband(raster, integer, text, double precision, double precision) is 'args: rast, index, pixeltype, initialvalue=0, nodataval=NULL - Returns a raster with the new band(s) of given type added with given initial value in the given index location. If no index is specified, the band is added to the end.';

alter function st_addband(raster, integer, text, double precision, double precision) owner to postgres;

