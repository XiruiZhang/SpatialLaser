create function st_approxquantile(rast raster, quantiles double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public._ST_quantile($1, 1, TRUE, 0.1, $2) $$;

alter function st_approxquantile(raster, double precision[], out double precision, out double precision) owner to postgres;

