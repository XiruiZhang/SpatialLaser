create view dfw_view(key, income, population, centroid, spatialobj, iswithinbuffer) as
SELECT d."Key"                                                                                                AS key,
       d.income,
       d.population,
       st_asgeojson(st_centroid(d.spatialobj))                                                                AS centroid,
       st_asgeojson(d.spatialobj)                                                                             AS spatialobj,
       st_within(st_centroid(d.spatialobj),
                 st_buffer(st_point(i.lng, i.lat)::geography, i.buffer)::geometry)                            AS iswithinbuffer
FROM dfw_demo d,
     dfw_view_input i;

alter table dfw_view
    owner to guest;

