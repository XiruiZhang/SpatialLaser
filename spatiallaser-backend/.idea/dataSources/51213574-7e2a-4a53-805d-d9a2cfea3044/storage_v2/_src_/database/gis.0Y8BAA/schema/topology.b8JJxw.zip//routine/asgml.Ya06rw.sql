create function asgml(tg topology.topogeometry, nsprefix text) returns text
    stable
    language sql
as
$$
 SELECT topology.AsGML($1, $2, 15, 1, NULL);
$$;

comment on function asgml(topology.topogeometry, text) is 'args: tg, nsprefix_in - Returns the GML representation of a topogeometry.';

alter function asgml(topology.topogeometry, text) owner to postgres;

